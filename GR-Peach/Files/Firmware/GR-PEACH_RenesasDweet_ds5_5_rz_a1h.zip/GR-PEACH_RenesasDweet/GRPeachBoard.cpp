#include "GRPeachBoard.h"
#include "Json.h"

#if 0
//Enable debug
    #include <cstdio>
    #define logInfo(x, ...) do{std::fprintf(stdout,"%s:%s:%s| [SecureDweet:INFO] "x"\r\n", __FILE__, __func__, __LINE__,##__VA_ARGS__);std::fflush(stdout);}while(0)
    #define logWarning(x, ...) do{std::fprintf(stdout,"%s:%s:%s| [SecureDweet:WARN] "x"\r\n", __FILE__, __func__, __LINE__,##__VA_ARGS__);std::fflush(stdout);}while(0)
    #define logError(x, ...) do{std::fprintf(stdout,"%s:%s:%s| [SecureDweet:ERROR] "x"\r\n", __FILE__, __func__, __LINE__,##__VA_ARGS__);std::fflush(stdout);}while(0)
#else
//Disable debug
    #define logInfo(x, ...)
#endif

#define logWarning(x, ...)
#define logError(x, ...)

GRPeachBoard::GRPeachBoard() :
        led1 (LED1), led2 (LED2), led3 (LED3), led4 (LED4), pb1(P6_0)
{
    led1 = false;
    led2 = false;
    led3 = false;
    led4 = false;
    
}

GRPeachBoard::GRPeachBoard(const GRPeachBoard & other) :
        led1 (LED1), led2 (LED2), led3 (LED3), led4 (LED4), pb1(P6_0)
{
}

GRPeachBoard::~GRPeachBoard()
{
}

void GRPeachBoard::parseJsonData(const char * jsonData)
{

    Json json (jsonData, strlen (jsonData));

    if (!json.isValidJson ())
    {
        logError("Invalid JSON received: %s", jsonData);
        return;
    }
    if (json.type (0) != JSMN_OBJECT)
    {
        logError("Invalid JSON received.  ROOT element is not Object: %s", jsonData);
        return;
    }

//    logInfo ( "Finding \"with\" Key ... " );
//    int withIndex = json.findKeyIndexIn ( "with", 0 );
//    if ( withIndex < 0 ) {
//        logError ( "Invalid JSON.  \"with\" not found" );
//        return;
//    }
//                
//    logInfo ( "Finding \"with\" Array ... withIndex: [%d]", withIndex );
//    int withArrayIndex = json.findChildIndexOf ( withIndex, -1 );
//    if ( ( withArrayIndex < 0 ) || ( json.type ( withArrayIndex ) != JSMN_ARRAY ) ) {
//        logError ( "Invalid JSON.  \"with\" Array not found" );
//        return;
//    }
//
//    logInfo ( "Finding \"with\" Array First Child ... withIndex: [%d], withArrayIndex: [%d]", withIndex, withArrayIndex );
//    int withFirstChildIndex = json.findChildIndexOf ( withArrayIndex, -1 );
//    if ( ( withFirstChildIndex < 0 ) || ( json.type ( withFirstChildIndex ) != JSMN_OBJECT ) ){
//        logError ( "Invalid JSON.  \"with\" First Child Object not found" );
//        return;
//    }

//    logInfo ( "Finding \"dweet\" Key Index ... withIndex: [%d], withArrayIndex: [%d], withFirstChildIndex: [%d]", withIndex, withArrayIndex, withFirstChildIndex );
//    logInfo ( "Finding \"content\" (dweet) Key Index" );
//    int dweetIndex = json.findKeyIndexIn ( "content", withFirstChildIndex );
    int dweetIndex = json.findKeyIndex ("content", 0);
    if ((dweetIndex < 0))
    {
        logError("Invalid JSON.  \"content\" not found");
        return;
    }

//    logInfo ( "Finding \"dweet\" Value Index ... withIndex: [%d], withArrayIndex: [%d], withFirstChildIndex: [%d], dweetIndex: [%d]", withIndex, withArrayIndex, withFirstChildIndex, dweetIndex );
//    logInfo ( "Finding \"dweet\" Value Index ... dweetIndex: [%d]", dweetIndex );
    int dweetValueIndex = json.findChildIndexOf (dweetIndex, -1);
    if ((dweetValueIndex < 0) || (json.type (dweetValueIndex) != JSMN_OBJECT))
    {
        logError("Invalid JSON.  \"content\" value not found");
        return;
    }

//    logInfo ( "Parsing the config now ... withIndex: [%d], withArrayIndex: [%d], withFirstChildIndex: [%d], dweetIndex: [%d], dweetValueIndex: [%d]", withIndex, withArrayIndex, withFirstChildIndex, dweetIndex, dweetValueIndex );
//    logInfo ( "Parsing the config now ... dweetIndex: [%d], dweetValueIndex: [%d]", dweetIndex, dweetValueIndex );

    parseLedValue (led1, json, "LED1", dweetValueIndex);
    parseLedValue (led2, json, "LED2", dweetValueIndex);
    parseLedValue (led3, json, "LED3", dweetValueIndex);
    parseLedValue (led4, json, "LED4", dweetValueIndex);
}

void GRPeachBoard::parseLedValue(DigitalOut & led, const Json & json, const char * keyName, int startingIndex)
{
    int ledIndex = json.findKeyIndexIn (keyName, startingIndex);
    if (ledIndex > 0)
    {
        int valueIndex = json.findChildIndexOf (ledIndex, 0);
        if (valueIndex > 0)
        {
            bool ledValue;
            json.tokenBooleanValue (valueIndex, ledValue);
            led = ledValue;
        }
    }
}

DigitalOut* GRPeachBoard::getLED(int i)
{
    if (i == 1)
    {
        return &led1;
    }
    if (i == 2)
    {
        return &led2;    
    }
    if (i == 3)
    {
        return &led3;    
    }
    if (i == 4)
    {
        return &led4;   
    }
}

//void GRPeachBoard :: loadConfig () {
//}

