#ifndef __GR_PEACH_BOARD_H_
#define __GR_PEACH_BOARD_H_

#include "IDweetParser.h"
#include "Json.h"
#include "mbed.h"

class GRPeachBoard: public IDweetParser
{
private:
    
    DigitalIn pb1;

    void parseLedValue(DigitalOut & led, const Json & json, const char * keyName, int startingIndex);

    GRPeachBoard(const GRPeachBoard & other);

public:
    
    DigitalOut led1;
    DigitalOut led2;
    DigitalOut led3;
    DigitalOut led4;
    
    GRPeachBoard();
    virtual ~GRPeachBoard();

    virtual void parseJsonData(const char * jsonData);
    virtual DigitalOut* getLED(int i);
};

#endif

