/* lhash.h for openSSL */


