/* ocsp.h for libcurl */

