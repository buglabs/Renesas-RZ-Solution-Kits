/* stack.h for openssl */


