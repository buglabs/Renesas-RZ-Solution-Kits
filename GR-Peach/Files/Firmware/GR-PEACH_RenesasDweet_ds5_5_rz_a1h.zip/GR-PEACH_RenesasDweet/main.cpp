#include "mbed.h"
#include "rtos.h"
#include "EthernetInterface.h"
#include "string.h"
#include "GRPeachBoard.h"
#include "SecureDweet.h"

bool isNetworkConnected = false;

void printAndFlush(void const * msg)
{
    fprintf ( stdout, "%s", (char *) msg);
    fflush ( stdout);
}

bool setupEthernet(EthernetInterface * & ethernet)
{
    printAndFlush ("\n\rConnecting Ethernet ...");

    RtosTimer * connectProgressTimer = new RtosTimer (printAndFlush, osTimerPeriodic, (void *) ".");
    connectProgressTimer->start (500);

    int err = ethernet->init ();
    char errMsg[256];
    if (err == 0)
    {
        err = ethernet->connect ();
        if (err == 0)
        {
            sprintf (
                    errMsg,
                    "\n\rEthernet connected with specs:\n\r\tIP Address:  %s\n\r\tSubnet Mask: %s\n\r\tGateway:     %s\n\r\tMAC Address: %s\n\r",
                    ethernet->getIPAddress (), ethernet->getNetworkMask (), ethernet->getGateway (),
                    ethernet->getMACAddress ());
        }
        else
        {
            sprintf (errMsg, " Ethernet connect failed with error: %d\n\r", err);
        }
    }
    else
    {
        sprintf (errMsg, " Ethernet init failed with error: %d\n\r", err);
    }

    printAndFlush (errMsg);
    connectProgressTimer->stop ();
    delete connectProgressTimer;

    return (err == 0);
}

//#error Update your thing name here, before proceeding further.  If you have \
  //     locked your thing, you need to set your READ_KEY as well.  Comment or 
    //   remove this warning macro after that.
 
#define THING_NAME  "peach_test"
#define WRITE_KEY   NULL
#define READ_KEY    NULL

int main(void)
{
    EthernetInterface * ethernet = new EthernetInterface ();
    IDweetParser * device = new GRPeachBoard (); // Implementation of IDweetParser

    SecureDweet * dweetManager = new SecureDweet (device, THING_NAME, READ_KEY);

    while (true)
    {
        if(!isNetworkConnected) 
        {
            isNetworkConnected = setupEthernet (ethernet);
        }
        
        dweetManager -> fetchLatestDweet ();
        
        wait(.5);
        dweetManager -> sendDweet();
        
        wait (.5);
        //dweetListener -> listenToDweet(); // this is an infinite blocking function call

//        // In another thread, use the following function call to stop listening
//        // to dweets (exit from the above function call)
//        // dweetListener -> stopListentingToDweet();
    }
}

